﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvailTourAgency.Models
{
    public class HotelRoomsInSales
    {
        public int ID { get; set; }
        public int SaleID { get; set; }
        public int HotelRoomID { get; set; }
    }
}
