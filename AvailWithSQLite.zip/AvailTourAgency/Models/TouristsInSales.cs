﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvailTourAgency.Models
{
    public class TouristsInSales
    {
        public int ID { get; set; }
        public int SaleID { get; set; }
        public int TouristID { get; set; }
    }
}
